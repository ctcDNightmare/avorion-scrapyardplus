local ScrapyardPlusConfig = {}

ScrapyardPlusConfig.version = "[0.1.0]"
ScrapyardPlusConfig.ModName = "[ScrapyardPlus]"
ScrapyardPlusConfig.AllowLifetime = false
ScrapyardPlusConfig.AlliancePriceFactor = 1.5

return ScrapyardPlusConfig
