local ScrapyardPlusConfig = {}

ScrapyardPlusConfig.version = "[1.2.0]"
ScrapyardPlusConfig.modName = "[ScrapyardPlus]"
ScrapyardPlusConfig.allowLifetime = true
ScrapyardPlusConfig.lifetimeLevelFactor = 1.0
ScrapyardPlusConfig.alliancePriceFactor = 4.5
ScrapyardPlusConfig.pricePerMinute = 175

return ScrapyardPlusConfig
